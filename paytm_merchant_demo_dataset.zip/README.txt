PAYTM MERCHANT GROWTH COPILOT - SYNTHETIC DEMO DATA

This package is synthetic demo data created for the hackathon project.
It is NOT live Paytm data and contains no real customer information.

Primary input:
  upi_transactions.csv
  - transaction amount, timestamp, status, customer hash, UPI reference, etc.
  - intentionally does NOT contain product/quantity fields because UPI payment
    records alone do not reliably identify the purchased items.

Merchant context:
  merchants.csv
  merchant_catalog.csv
  customers.csv

Optional exact item-level evidence:
  merchant_orders.csv
  This represents POS/order data that would be available if a merchant's
  ordering system is integrated. It should not be described as information
  obtained from UPI itself.

The backend can:
  1. Filter SUCCESS transactions.
  2. Calculate revenue, transaction count and average transaction value.
  3. Calculate hourly/day-of-week demand.
  4. Calculate repeat-customer metrics from customer_id_hash.
  5. Use merchant_orders.csv when exact item data exists.
  6. Otherwise infer likely baskets from amount + catalogue + historical
     patterns and attach a confidence score.
  7. Detect low-sales hours, slow-moving products, bundles and opportunities.
  8. Run ProfitGuard before presenting an action.

Suggested demo merchant:
  Sri Lakshmi Tea & Snacks, BTM Layout, Bengaluru.

Date range:
  2026-06-20 through 2026-09-17.

All names, transaction IDs, UPI references and customer hashes are synthetic.
